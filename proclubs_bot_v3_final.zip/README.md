# Rachad Pro Clubs Bot v3

## Quick Deploy

### 1. Files you need from this zip
Extract everything into your repo root. Keep your existing:
- `squad.json` (your player registry)
- `phrases.py` (your Darija roast pools)
- `assets/` folder (player photos)

### 2. Install locally
```bash
pip install -r requirements.txt
playwright install chromium
python -m src.main
```

### 3. Environment variables (.env)
```
DISCORD_TOKEN=your_token_here
DISCORD_GUILD_ID=your_guild_id
MATCH_CHANNEL_ID=your_match_channel
DAILY_CHANNEL_ID=your_daily_channel
LEADERBOARD_CHANNEL_ID=your_lb_channel
CLUB_ID=1427607
PCT_PLATFORM=common-gen5
PCT_CLUB_URL=https://proclubstracker.com/club/1427607?platform=common-gen5&div=6
```

### 4. Deploy to Render
- Connect your GitHub repo
- Set environment variables in Render dashboard
- Health check: `http://your-app.fly.dev/health` (port 8000)

## Architecture

```
src/
├── core/          # Config, logging, errors, app context
├── data/          # SQLite DB, schema, repositories
├── domain/        # Pydantic models (Match, Player, etc.)
├── discord_layer/ # Bot factory, all 20 slash commands
├── engine/        # Card gen, roast gen, video gen
├── scraper/       # Playwright ProClubsTracker client
├── services/      # Match service, auto-content, health
├── squad/         # Squad registry from squad.json
└── utils/         # Text helpers
```

## Hard Data Rules (Enforced)
- `match.players` = ONLY source of truth for match data
- `squad.json` = identity registry ONLY (EA ID, nickname, image, personality)
- Opponents NEVER appear in commands
- Absent squad members NEVER appear in commands
- All commands validate player presence in `match.players`

## Commands (All Working)
- `/sync` - Fetch latest from ProClubsTracker
- `/status` - Show data status
- `/player <name>` - Profile + card
- `/mvp` - MVP of latest match
- `/fraud [name]` - Fraud verdict
- `/ghost` - Ghost verdict
- `/carry` - Carry detector
- `/who_sold` - Who sold the match
- `/ball_loser` - Ball loss merchant
- `/playmaker` - Pass dictator
- `/sniper` - Shot efficiency king
- `/compare <p1> <p2>` - 1v1 comparison
- `/court_case <player>` - Tribunal
- `/club` - Club summary
- `/records` - Records (coming)
- `/form <player>` - Recent form
- `/awards` - Weekly awards
- `/legend [player]` - Hall of Fame card
- `/hall_of_shame` - Shame museum (coming)
- `/hall_of_fame` - Fame museum (coming)
- `/match_report` - Latest match report
- `/leaderboard [metric]` - Leaderboard

## Auto Content
- Match reports posted to MATCH_CHANNEL every 5 min
- Weekly Fraud/Ghost/MVP posted to DAILY_CHANNEL daily
